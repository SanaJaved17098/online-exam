import React from 'react'
import Navbar from './Navbar'
function ContactUs() {
  return (
    
    <div>
        <Navbar/>
        

    comming soon

    </div>
  )
}

export default ContactUs