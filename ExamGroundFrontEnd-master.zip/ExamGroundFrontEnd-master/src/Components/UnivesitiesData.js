export const university=["Numl","Bahria",'Comsat','Fast',"Maju"];
//[
    
//     {
//         id:0,
//         label:'select University',
//         name:'Select University',
//     },
//     {
//         id:1,
//         label:'NUML',
//         name:'NUML University',
//     },
//     {
//         id:2,
//         label:'NUST',
//         name:'NUST',
//     },
//     {
//         id:3,
//         label:'BAHRIA',
//         name:'BAHRIA',
//     },
    
//     {
//         id:4,
//         label:'COMSATT',
//         name:'COMSATT ISLAMABAD',
//     },
    
//     {
//         id:5,
//         label:'FAST',
//         name:'FAST',
//     },
    
    
// ]